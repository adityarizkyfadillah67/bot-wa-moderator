pkg install kepala -y
pkg install ku -y
pkg install adadua -y
npm install
