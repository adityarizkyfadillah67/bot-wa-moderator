let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 INFO BOT 〙 ═
╠➥ Dibuat dengan bahasa javascript 
╠➥ Rec: Drawl Nag
╠➥ Script: wa.me/6281347225026
║
╠➥ Github: https://github.com/Arya274/Arya-DN
╠➥ YouTube: https://www.youtube.com/channel/UCfxkQA4MOcHokwziew91meg
║
╠═〘 Thanks To 〙 ═
╠➥ Aditya Rizky Fadillah (MODDER
╠➥ RAMA BONCELLL
╠➥ REZZY
╠➥ KIRIGAYA
╠➥ MORPG Team
║
╠═〘 DONASI 〙 ═
╠➥ Dana: 081347225026
╠➥ Tsel: 081347225026
║
║>Request? Wa.me/6281347225026
║
╠═〘 NfQ BOT 〙 ═
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

