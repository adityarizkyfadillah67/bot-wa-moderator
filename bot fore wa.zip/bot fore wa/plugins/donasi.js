let handler = async m => m.reply(`
╭─「 Donasi • Pulsa • Saldo Dana」
│ • Smartfren [081347225026]
│ • Telkomsel [081347225026]
│ • Gopay [081357302007]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? wa.me/6281347225026
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
